export declare class UserModule {
}
