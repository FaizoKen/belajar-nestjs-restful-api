import { LoginUserRequest, RegisterUserRequest, UpdateUserRequest, UserResponse } from '../model/user.model';
import { ValidationService } from '../common/validation.service';
import { Logger } from 'winston';
import { PrismaService } from '../common/prisma.service';
import { User } from '@prisma/client';
export declare class UserService {
    private validationService;
    private logger;
    private prismaService;
    constructor(validationService: ValidationService, logger: Logger, prismaService: PrismaService);
    register(request: RegisterUserRequest): Promise<UserResponse>;
    login(request: LoginUserRequest): Promise<UserResponse>;
    get(user: User): Promise<UserResponse>;
    update(user: User, request: UpdateUserRequest): Promise<UserResponse>;
    logout(user: User): Promise<UserResponse>;
}
