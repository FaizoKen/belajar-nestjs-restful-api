import { UserService } from './user.service';
import { WebResponse } from '../model/web.model';
import { LoginUserRequest, RegisterUserRequest, UpdateUserRequest, UserResponse } from '../model/user.model';
import { User } from '@prisma/client';
export declare class UserController {
    private userService;
    constructor(userService: UserService);
    register(request: RegisterUserRequest): Promise<WebResponse<UserResponse>>;
    login(request: LoginUserRequest): Promise<WebResponse<UserResponse>>;
    get(user: User): Promise<WebResponse<UserResponse>>;
    update(user: User, request: UpdateUserRequest): Promise<WebResponse<UserResponse>>;
    logout(user: User): Promise<WebResponse<boolean>>;
}
