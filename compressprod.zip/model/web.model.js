"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Paging = exports.WebResponse = void 0;
class WebResponse {
}
exports.WebResponse = WebResponse;
class Paging {
}
exports.Paging = Paging;
//# sourceMappingURL=web.model.js.map