export declare const Auth: (...dataOrPipes: unknown[]) => ParameterDecorator;
