import { Logger } from 'winston';
import { PrismaService } from '../common/prisma.service';
import { Contact, User } from '@prisma/client';
import { ContactResponse, CreateContactRequest, SearchContactRequest, UpdateContactRequest } from '../model/contact.model';
import { ValidationService } from '../common/validation.service';
import { WebResponse } from '../model/web.model';
export declare class ContactService {
    private logger;
    private prismaService;
    private validationService;
    constructor(logger: Logger, prismaService: PrismaService, validationService: ValidationService);
    create(user: User, request: CreateContactRequest): Promise<ContactResponse>;
    toContactResponse(contact: Contact): ContactResponse;
    checkContactMustExists(username: string, contactId: number): Promise<Contact>;
    get(user: User, contactId: number): Promise<ContactResponse>;
    update(user: User, request: UpdateContactRequest): Promise<ContactResponse>;
    remove(user: User, contactId: number): Promise<ContactResponse>;
    search(user: User, request: SearchContactRequest): Promise<WebResponse<ContactResponse[]>>;
}
