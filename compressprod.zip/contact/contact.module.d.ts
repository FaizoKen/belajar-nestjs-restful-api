export declare class ContactModule {
}
