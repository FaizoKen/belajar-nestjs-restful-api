import { AddressService } from './address.service';
import { WebResponse } from '../model/web.model';
import { AddressResponse, CreateAddressRequest, UpdateAddressRequest } from '../model/address.model';
import { User } from '@prisma/client';
export declare class AddressController {
    private addressService;
    constructor(addressService: AddressService);
    create(user: User, contactId: number, request: CreateAddressRequest): Promise<WebResponse<AddressResponse>>;
    get(user: User, contactId: number, addressId: number): Promise<WebResponse<AddressResponse>>;
    update(user: User, contactId: number, addressId: number, request: UpdateAddressRequest): Promise<WebResponse<AddressResponse>>;
    remove(user: User, contactId: number, addressId: number): Promise<WebResponse<boolean>>;
    list(user: User, contactId: number): Promise<WebResponse<AddressResponse[]>>;
}
