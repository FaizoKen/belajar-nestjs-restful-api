import { Logger } from 'winston';
import { PrismaService } from '../common/prisma.service';
import { ValidationService } from '../common/validation.service';
import { Address, User } from '@prisma/client';
import { AddressResponse, CreateAddressRequest, GetAddressRequest, RemoveAddressRequest, UpdateAddressRequest } from '../model/address.model';
import { ContactService } from '../contact/contact.service';
export declare class AddressService {
    private logger;
    private prismaService;
    private validationService;
    private contactService;
    constructor(logger: Logger, prismaService: PrismaService, validationService: ValidationService, contactService: ContactService);
    create(user: User, request: CreateAddressRequest): Promise<AddressResponse>;
    toAddressResponse(address: Address): AddressResponse;
    checkAddressMustExists(contactId: number, addressId: number): Promise<Address>;
    get(user: User, request: GetAddressRequest): Promise<AddressResponse>;
    update(user: User, request: UpdateAddressRequest): Promise<AddressResponse>;
    remove(user: User, request: RemoveAddressRequest): Promise<AddressResponse>;
    list(user: User, contactId: number): Promise<AddressResponse[]>;
}
