"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddressController = void 0;
const common_1 = require("@nestjs/common");
const address_service_1 = require("./address.service");
const address_model_1 = require("../model/address.model");
const auth_decorator_1 = require("../common/auth.decorator");
let AddressController = class AddressController {
    constructor(addressService) {
        this.addressService = addressService;
    }
    async create(user, contactId, request) {
        request.contact_id = contactId;
        const result = await this.addressService.create(user, request);
        return {
            data: result,
        };
    }
    async get(user, contactId, addressId) {
        const request = {
            address_id: addressId,
            contact_id: contactId,
        };
        const result = await this.addressService.get(user, request);
        return {
            data: result,
        };
    }
    async update(user, contactId, addressId, request) {
        request.contact_id = contactId;
        request.id = addressId;
        const result = await this.addressService.update(user, request);
        return {
            data: result,
        };
    }
    async remove(user, contactId, addressId) {
        const request = {
            address_id: addressId,
            contact_id: contactId,
        };
        await this.addressService.remove(user, request);
        return {
            data: true,
        };
    }
    async list(user, contactId) {
        const result = await this.addressService.list(user, contactId);
        return {
            data: result,
        };
    }
};
exports.AddressController = AddressController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(200),
    __param(0, (0, auth_decorator_1.Auth)()),
    __param(1, (0, common_1.Param)('contactId', common_1.ParseIntPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, address_model_1.CreateAddressRequest]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "create", null);
__decorate([
    (0, common_1.Get)('/:addressId'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, auth_decorator_1.Auth)()),
    __param(1, (0, common_1.Param)('contactId', common_1.ParseIntPipe)),
    __param(2, (0, common_1.Param)('addressId', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "get", null);
__decorate([
    (0, common_1.Put)('/:addressId'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, auth_decorator_1.Auth)()),
    __param(1, (0, common_1.Param)('contactId', common_1.ParseIntPipe)),
    __param(2, (0, common_1.Param)('addressId', common_1.ParseIntPipe)),
    __param(3, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number, address_model_1.UpdateAddressRequest]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)('/:addressId'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, auth_decorator_1.Auth)()),
    __param(1, (0, common_1.Param)('contactId', common_1.ParseIntPipe)),
    __param(2, (0, common_1.Param)('addressId', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number, Number]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)(),
    (0, common_1.HttpCode)(200),
    __param(0, (0, auth_decorator_1.Auth)()),
    __param(1, (0, common_1.Param)('contactId', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Number]),
    __metadata("design:returntype", Promise)
], AddressController.prototype, "list", null);
exports.AddressController = AddressController = __decorate([
    (0, common_1.Controller)('/api/contacts/:contactId/addresses'),
    __metadata("design:paramtypes", [address_service_1.AddressService])
], AddressController);
//# sourceMappingURL=address.controller.js.map