import { ZodType } from 'zod';
export declare class AddressValidation {
    static readonly CREATE: ZodType;
    static readonly GET: ZodType;
    static readonly UPDATE: ZodType;
    static readonly REMOVE: ZodType;
}
