export declare class AddressModule {
}
