"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddressService = void 0;
const common_1 = require("@nestjs/common");
const nest_winston_1 = require("nest-winston");
const winston_1 = require("winston");
const prisma_service_1 = require("../common/prisma.service");
const validation_service_1 = require("../common/validation.service");
const address_validation_1 = require("./address.validation");
const contact_service_1 = require("../contact/contact.service");
let AddressService = class AddressService {
    constructor(logger, prismaService, validationService, contactService) {
        this.logger = logger;
        this.prismaService = prismaService;
        this.validationService = validationService;
        this.contactService = contactService;
    }
    async create(user, request) {
        this.logger.debug(`AddressService.create(${JSON.stringify(user)}, ${JSON.stringify(request)})`);
        const createRequest = this.validationService.validate(address_validation_1.AddressValidation.CREATE, request);
        await this.contactService.checkContactMustExists(user.username, createRequest.contact_id);
        const address = await this.prismaService.address.create({
            data: createRequest,
        });
        return this.toAddressResponse(address);
    }
    toAddressResponse(address) {
        return {
            id: address.id,
            street: address.street,
            city: address.city,
            province: address.province,
            country: address.country,
            postal_code: address.postal_code,
        };
    }
    async checkAddressMustExists(contactId, addressId) {
        const address = await this.prismaService.address.findFirst({
            where: {
                id: addressId,
                contact_id: contactId,
            },
        });
        if (!address) {
            throw new common_1.HttpException('Address is not found', 404);
        }
        return address;
    }
    async get(user, request) {
        const getRequest = this.validationService.validate(address_validation_1.AddressValidation.GET, request);
        await this.contactService.checkContactMustExists(user.username, getRequest.contact_id);
        const address = await this.checkAddressMustExists(getRequest.contact_id, getRequest.address_id);
        return this.toAddressResponse(address);
    }
    async update(user, request) {
        const updateRequest = this.validationService.validate(address_validation_1.AddressValidation.UPDATE, request);
        await this.contactService.checkContactMustExists(user.username, updateRequest.contact_id);
        let address = await this.checkAddressMustExists(updateRequest.contact_id, updateRequest.id);
        address = await this.prismaService.address.update({
            where: {
                id: address.id,
                contact_id: address.contact_id,
            },
            data: updateRequest,
        });
        return this.toAddressResponse(address);
    }
    async remove(user, request) {
        const removeRequest = this.validationService.validate(address_validation_1.AddressValidation.REMOVE, request);
        await this.contactService.checkContactMustExists(user.username, removeRequest.contact_id);
        await this.checkAddressMustExists(removeRequest.contact_id, removeRequest.address_id);
        const address = await this.prismaService.address.delete({
            where: {
                id: removeRequest.address_id,
                contact_id: removeRequest.contact_id,
            },
        });
        return this.toAddressResponse(address);
    }
    async list(user, contactId) {
        await this.contactService.checkContactMustExists(user.username, contactId);
        const addresses = await this.prismaService.address.findMany({
            where: {
                contact_id: contactId,
            },
        });
        return addresses.map((address) => this.toAddressResponse(address));
    }
};
exports.AddressService = AddressService;
exports.AddressService = AddressService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(nest_winston_1.WINSTON_MODULE_PROVIDER)),
    __metadata("design:paramtypes", [winston_1.Logger,
        prisma_service_1.PrismaService,
        validation_service_1.ValidationService,
        contact_service_1.ContactService])
], AddressService);
//# sourceMappingURL=address.service.js.map