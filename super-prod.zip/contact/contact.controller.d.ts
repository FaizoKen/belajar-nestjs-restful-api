import { ContactService } from './contact.service';
import { User } from '@prisma/client';
import { ContactResponse, CreateContactRequest, UpdateContactRequest } from '../model/contact.model';
import { WebResponse } from '../model/web.model';
export declare class ContactController {
    private contactService;
    constructor(contactService: ContactService);
    create(user: User, request: CreateContactRequest): Promise<WebResponse<ContactResponse>>;
    get(user: User, contactId: number): Promise<WebResponse<ContactResponse>>;
    update(user: User, contactId: number, request: UpdateContactRequest): Promise<WebResponse<ContactResponse>>;
    remove(user: User, contactId: number): Promise<WebResponse<boolean>>;
    search(user: User, name?: string, email?: string, phone?: string, page?: number, size?: number): Promise<WebResponse<ContactResponse[]>>;
}
