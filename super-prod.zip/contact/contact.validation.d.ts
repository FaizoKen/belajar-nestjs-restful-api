import { ZodType } from 'zod';
export declare class ContactValidation {
    static readonly CREATE: ZodType;
    static readonly UPDATE: ZodType;
    static readonly SEARCH: ZodType;
}
