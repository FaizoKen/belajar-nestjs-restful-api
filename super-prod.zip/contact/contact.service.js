"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactService = void 0;
const common_1 = require("@nestjs/common");
const nest_winston_1 = require("nest-winston");
const winston_1 = require("winston");
const prisma_service_1 = require("../common/prisma.service");
const validation_service_1 = require("../common/validation.service");
const contact_validation_1 = require("./contact.validation");
let ContactService = class ContactService {
    constructor(logger, prismaService, validationService) {
        this.logger = logger;
        this.prismaService = prismaService;
        this.validationService = validationService;
    }
    async create(user, request) {
        this.logger.debug(`ContactService.create(${JSON.stringify(user)}, ${JSON.stringify(request)})`);
        const createRequest = this.validationService.validate(contact_validation_1.ContactValidation.CREATE, request);
        const contact = await this.prismaService.contact.create({
            data: {
                ...createRequest,
                ...{ username: user.username },
            },
        });
        return this.toContactResponse(contact);
    }
    toContactResponse(contact) {
        return {
            first_name: contact.first_name,
            last_name: contact.last_name,
            email: contact.email,
            phone: contact.phone,
            id: contact.id,
        };
    }
    async checkContactMustExists(username, contactId) {
        const contact = await this.prismaService.contact.findFirst({
            where: {
                username: username,
                id: contactId,
            },
        });
        if (!contact) {
            throw new common_1.HttpException('Contact is not found', 404);
        }
        return contact;
    }
    async get(user, contactId) {
        const contact = await this.checkContactMustExists(user.username, contactId);
        return this.toContactResponse(contact);
    }
    async update(user, request) {
        const updateRequest = this.validationService.validate(contact_validation_1.ContactValidation.UPDATE, request);
        let contact = await this.checkContactMustExists(user.username, updateRequest.id);
        contact = await this.prismaService.contact.update({
            where: {
                id: contact.id,
                username: contact.username,
            },
            data: updateRequest,
        });
        return this.toContactResponse(contact);
    }
    async remove(user, contactId) {
        await this.checkContactMustExists(user.username, contactId);
        const contact = await this.prismaService.contact.delete({
            where: {
                id: contactId,
                username: user.username,
            },
        });
        return this.toContactResponse(contact);
    }
    async search(user, request) {
        const searchRequest = this.validationService.validate(contact_validation_1.ContactValidation.SEARCH, request);
        const filters = [];
        if (searchRequest.name) {
            filters.push({
                OR: [
                    {
                        first_name: {
                            contains: searchRequest.name,
                        },
                    },
                    {
                        last_name: {
                            contains: searchRequest.name,
                        },
                    },
                ],
            });
        }
        if (searchRequest.email) {
            filters.push({
                email: {
                    contains: searchRequest.email,
                },
            });
        }
        if (searchRequest.phone) {
            filters.push({
                phone: {
                    contains: searchRequest.phone,
                },
            });
        }
        const skip = (searchRequest.page - 1) * searchRequest.size;
        const contacts = await this.prismaService.contact.findMany({
            where: {
                username: user.username,
                AND: filters,
            },
            take: searchRequest.size,
            skip: skip,
        });
        const total = await this.prismaService.contact.count({
            where: {
                username: user.username,
                AND: filters,
            },
        });
        return {
            data: contacts.map((contact) => this.toContactResponse(contact)),
            paging: {
                current_page: searchRequest.page,
                size: searchRequest.size,
                total_page: Math.ceil(total / searchRequest.size),
            },
        };
    }
};
exports.ContactService = ContactService;
exports.ContactService = ContactService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(nest_winston_1.WINSTON_MODULE_PROVIDER)),
    __metadata("design:paramtypes", [winston_1.Logger,
        prisma_service_1.PrismaService,
        validation_service_1.ValidationService])
], ContactService);
//# sourceMappingURL=contact.service.js.map