import { ZodType } from 'zod';
export declare class UserValidation {
    static readonly REGISTER: ZodType;
    static readonly LOGIN: ZodType;
    static readonly UPDATE: ZodType;
}
