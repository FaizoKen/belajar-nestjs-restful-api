"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const validation_service_1 = require("../common/validation.service");
const winston_1 = require("winston");
const nest_winston_1 = require("nest-winston");
const prisma_service_1 = require("../common/prisma.service");
const user_validation_1 = require("./user.validation");
const bcrypt = require("bcrypt");
const uuid_1 = require("uuid");
let UserService = class UserService {
    constructor(validationService, logger, prismaService) {
        this.validationService = validationService;
        this.logger = logger;
        this.prismaService = prismaService;
    }
    async register(request) {
        this.logger.debug(`Register new user ${JSON.stringify(request)}`);
        const registerRequest = this.validationService.validate(user_validation_1.UserValidation.REGISTER, request);
        const totalUserWithSameUsername = await this.prismaService.user.count({
            where: {
                username: registerRequest.username,
            },
        });
        if (totalUserWithSameUsername != 0) {
            throw new common_1.HttpException('Username already exists', 400);
        }
        registerRequest.password = await bcrypt.hash(registerRequest.password, 10);
        const user = await this.prismaService.user.create({
            data: registerRequest,
        });
        return {
            username: user.username,
            name: user.name,
        };
    }
    async login(request) {
        this.logger.debug(`UserService.login(${JSON.stringify(request)})`);
        const loginRequest = this.validationService.validate(user_validation_1.UserValidation.LOGIN, request);
        let user = await this.prismaService.user.findUnique({
            where: {
                username: loginRequest.username,
            },
        });
        if (!user) {
            throw new common_1.HttpException('Username or password is invalid', 401);
        }
        const isPasswordValid = await bcrypt.compare(loginRequest.password, user.password);
        if (!isPasswordValid) {
            throw new common_1.HttpException('Username or password is invalid', 401);
        }
        user = await this.prismaService.user.update({
            where: {
                username: loginRequest.username,
            },
            data: {
                token: (0, uuid_1.v4)(),
            },
        });
        return {
            username: user.username,
            name: user.name,
            token: user.token,
        };
    }
    async get(user) {
        return {
            username: user.username,
            name: user.name,
        };
    }
    async update(user, request) {
        this.logger.debug(`UserService.update( ${JSON.stringify(user)} , ${JSON.stringify(request)} )`);
        const updateRequest = this.validationService.validate(user_validation_1.UserValidation.UPDATE, request);
        if (updateRequest.name) {
            user.name = updateRequest.name;
        }
        if (updateRequest.password) {
            user.password = await bcrypt.hash(updateRequest.password, 10);
        }
        const result = await this.prismaService.user.update({
            where: {
                username: user.username,
            },
            data: user,
        });
        return {
            name: result.name,
            username: result.username,
        };
    }
    async logout(user) {
        const result = await this.prismaService.user.update({
            where: {
                username: user.username,
            },
            data: {
                token: null,
            },
        });
        return {
            username: result.username,
            name: result.name,
        };
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Inject)(nest_winston_1.WINSTON_MODULE_PROVIDER)),
    __metadata("design:paramtypes", [validation_service_1.ValidationService,
        winston_1.Logger,
        prisma_service_1.PrismaService])
], UserService);
//# sourceMappingURL=user.service.js.map