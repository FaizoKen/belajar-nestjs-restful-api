export declare class ContactResponse {
    id: number;
    first_name: string;
    last_name?: string;
    email?: string;
    phone?: string;
}
export declare class CreateContactRequest {
    first_name: string;
    last_name?: string;
    email?: string;
    phone?: string;
}
export declare class UpdateContactRequest {
    id: number;
    first_name: string;
    last_name?: string;
    email?: string;
    phone?: string;
}
export declare class SearchContactRequest {
    name?: string;
    email?: string;
    phone?: string;
    page: number;
    size: number;
}
