export declare class RegisterUserRequest {
    username: string;
    password: string;
    name: string;
}
export declare class UserResponse {
    username: string;
    name: string;
    token?: string;
}
export declare class LoginUserRequest {
    username: string;
    password: string;
}
export declare class UpdateUserRequest {
    name?: string;
    password?: string;
}
