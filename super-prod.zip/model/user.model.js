"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateUserRequest = exports.LoginUserRequest = exports.UserResponse = exports.RegisterUserRequest = void 0;
class RegisterUserRequest {
}
exports.RegisterUserRequest = RegisterUserRequest;
class UserResponse {
}
exports.UserResponse = UserResponse;
class LoginUserRequest {
}
exports.LoginUserRequest = LoginUserRequest;
class UpdateUserRequest {
}
exports.UpdateUserRequest = UpdateUserRequest;
//# sourceMappingURL=user.model.js.map