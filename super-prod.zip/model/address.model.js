"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RemoveAddressRequest = exports.UpdateAddressRequest = exports.GetAddressRequest = exports.CreateAddressRequest = exports.AddressResponse = void 0;
class AddressResponse {
}
exports.AddressResponse = AddressResponse;
class CreateAddressRequest {
}
exports.CreateAddressRequest = CreateAddressRequest;
class GetAddressRequest {
}
exports.GetAddressRequest = GetAddressRequest;
class UpdateAddressRequest {
}
exports.UpdateAddressRequest = UpdateAddressRequest;
class RemoveAddressRequest {
}
exports.RemoveAddressRequest = RemoveAddressRequest;
//# sourceMappingURL=address.model.js.map