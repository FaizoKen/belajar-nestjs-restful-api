export declare class AddressResponse {
    id: number;
    street?: string;
    city?: string;
    province?: string;
    country: string;
    postal_code: string;
}
export declare class CreateAddressRequest {
    contact_id: number;
    street?: string;
    city?: string;
    province?: string;
    country: string;
    postal_code: string;
}
export declare class GetAddressRequest {
    contact_id: number;
    address_id: number;
}
export declare class UpdateAddressRequest {
    id: number;
    contact_id: number;
    street?: string;
    city?: string;
    province?: string;
    country: string;
    postal_code: string;
}
export declare class RemoveAddressRequest {
    contact_id: number;
    address_id: number;
}
