"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchContactRequest = exports.UpdateContactRequest = exports.CreateContactRequest = exports.ContactResponse = void 0;
class ContactResponse {
}
exports.ContactResponse = ContactResponse;
class CreateContactRequest {
}
exports.CreateContactRequest = CreateContactRequest;
class UpdateContactRequest {
}
exports.UpdateContactRequest = UpdateContactRequest;
class SearchContactRequest {
}
exports.SearchContactRequest = SearchContactRequest;
//# sourceMappingURL=contact.model.js.map